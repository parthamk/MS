const mongoose = require('mongoose');

const schoolSchema = new mongoose.Schema({
  name: { type: String, required: true },
  fees: { type: String, required: true },
  picture: { type: String },
  details: { type: String },
});

const School = mongoose.model('School', schoolSchema);

module.exports = School;