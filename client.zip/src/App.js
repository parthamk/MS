import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AdminPage from './components/AdminPage/AdminPage';
import ParentsPage from './components/ParentsPage/ParentsPage';
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  return (
    <Router>
      <div className="container">
        <Routes>
          <Route path="/admin" element={<AdminPage/>} />
          <Route path="/" element={<ParentsPage/>} />
        </Routes>
      </div>
    </Router>
  )
}

export default App