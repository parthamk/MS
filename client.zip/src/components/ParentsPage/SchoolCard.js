import React, { useEffect, useState } from 'react'
import { Card, Button } from 'react-bootstrap';
import axios from 'axios';

const SchoolCard = () => {
  const [schools, setSchools] = useState([])
   // Dummy school data, replace with actual data from backend
  //  const schools = [
  //   { name: 'School A', fees: '$1000', picture: 'school-a.jpg', details: 'Details about School A' },
  //   { name: 'School B', fees: '$1500', picture: 'school-b.jpg', details: 'Details about School B' },
  // ];

  useEffect(() => {
    const fetchSchools = async() => {
      try {
        const response = await axios.get('http://localhost:5000/api/schools');
        setSchools(response.data);
      } catch (error) {
        console.error('Error fetching schools:', error);
      }
    }
    fetchSchools(); 
  },[])

  return (
    <div>
      {schools.map(({ _id, name, fees, picture, details }) => (
        <Card key={_id} style={{ width: '18rem' }}>
          <Card.Img variant="top" src={picture} />
          <Card.Body>
            <Card.Title>{name}</Card.Title>
            <Card.Text>Fees: {fees}</Card.Text>
            <Card.Text>{details}</Card.Text>
            {/* <Button variant="primary">Edit</Button> */}
            {/* <Button variant="danger">Delete</Button> */}
          </Card.Body>
        </Card>
      ))}
    </div>
  );
}

export default SchoolCard