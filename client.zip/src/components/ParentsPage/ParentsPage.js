import React from 'react'
import SchoolCard from './SchoolCard';

const ParentsPage = () => {
  return (
    <div>
        <h2>Parents Page</h2>
        <SchoolCard />
    </div>
  )
}

export default ParentsPage