import React from 'react'
import SchoolForm from './SchoolForm';
import SchoolCard from './SchoolCard';

const AdminPage = () => {
  return (
    <div>
        <h2>Admin Page</h2>
        <SchoolForm />
        <SchoolCard />
    </div>
  )
}

export default AdminPage