import React, { useEffect, useState } from 'react'
import { Card, Button } from 'react-bootstrap'
import axios from 'axios';
import SchoolForm from './SchoolForm';


const SchoolCard = () => {
  const [schools, setSchools] = useState([]);

  useEffect(() => {
    const fetchSchools = async() => {
      try {
        const response = await axios.get('http://localhost:5000/api/schools');
        setSchools(response.data);
      } catch (error) {
        console.error('Error fetching schools:', error);
      }
    }
    fetchSchools();
  },[])

  const updateData = async(schoolId) => {
    const updateInfo = {
      name: "Updated School Name",
      fees: "Updated Fees",
      details: "Updated Details"
    };
    try {
      const updateResponse = await axios.put(`http://localhost:5000/api/schools/${schoolId}`, updateInfo);
      console.log('Update successful:', updateResponse.data);
    } catch (error) {
      console.error('Error updating school:', error);
    }
  }

  return (
    <div>
      {schools.map(({ _id, name, fees, picture, details }) => (
        <Card key={_id} style={{ width: '18rem' }}>
          <Card.Img variant="top" src={picture} />
          <Card.Body>
            <Card.Title>{name}</Card.Title>
            <Card.Text>Fees: {fees}</Card.Text>
            <Card.Text>{details}</Card.Text>
            <Button variant="primary" onClick={()=>updateData(_id)}>Edit</Button>
            <Button variant="danger">Delete</Button>
          </Card.Body>
        </Card>
      ))}
    </div>
  );
}

export default SchoolCard